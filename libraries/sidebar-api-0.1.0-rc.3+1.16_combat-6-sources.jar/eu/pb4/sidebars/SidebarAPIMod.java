package eu.pb4.sidebars;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2585;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_274;
import java.util.ArrayList;
import java.util.List;

public class SidebarAPIMod implements ModInitializer {
    public static final List<class_268> TEAMS = new ArrayList<>();
    public static final List<String> FAKE_PLAYER_NAMES = new ArrayList<>();
    public static final class_269 SCOREBOARD = new class_269();
    public static final String OBJECTIVE_NAME = "■SidebarApiObj";
    public static final String TEAM_NAME = "■SidebarApi-";
    public static final class_266 SCOREBOARD_OBJECTIVE = new class_266(SCOREBOARD, OBJECTIVE_NAME, class_274.field_1468, new class_2585("Something went wrong..."), class_274.class_275.field_1472);

    @Override
    public void onInitialize() {
        for (int x = 0; x < 15; x++) {
            String fakePlayerName = String.format("§%s§r", Integer.toHexString(x));
            class_268 team = new class_268(SCOREBOARD, TEAM_NAME + x);
            SCOREBOARD.method_1172(fakePlayerName, team);

            TEAMS.add(team);
            FAKE_PLAYER_NAMES.add(fakePlayerName);
        }
    }
}
