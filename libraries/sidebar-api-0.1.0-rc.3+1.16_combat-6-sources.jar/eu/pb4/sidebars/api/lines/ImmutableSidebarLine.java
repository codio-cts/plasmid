package eu.pb4.sidebars.api.lines;

import eu.pb4.sidebars.api.Sidebar;
import net.minecraft.class_2561;
import net.minecraft.class_3244;
import org.jetbrains.annotations.Nullable;

/**
 * Immutable version of SidebarLine used for comparison of change.
 */
public record ImmutableSidebarLine(int value, class_2561 text) implements SidebarLine {

    @Override
    public int getValue() {
        return this.value;
    }

    @Override
    public boolean setValue(int value) {
        return false;
    }

    @Override
    public class_2561 getText(class_3244 handler) {
        return this.text;
    }

    @Override
    public void setSidebar(@Nullable Sidebar sidebar) {}

    public boolean equals(Object o, class_3244 handler) {
        if (this == o) return true;
        if (!(o instanceof SidebarLine that)) return false;
        return this.value == that.getValue() && that.getText(handler).equals(this.text);
    }
}
