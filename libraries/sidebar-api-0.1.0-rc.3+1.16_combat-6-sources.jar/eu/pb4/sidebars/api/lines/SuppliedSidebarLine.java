package eu.pb4.sidebars.api.lines;

import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

public class SuppliedSidebarLine extends AbstractSidebarLine {
    private final Function<class_3222, class_2561> func;

    public SuppliedSidebarLine(int value, Function<@Nullable class_3222, class_2561> func) {
        this.value = value;
        this.func = func;
    }

    public class_2561 getText() {
        return this.func.apply(null);
    }

    public class_2561 getText(class_3244 handler) {
        return this.func.apply(handler.field_14140);
    }
}
