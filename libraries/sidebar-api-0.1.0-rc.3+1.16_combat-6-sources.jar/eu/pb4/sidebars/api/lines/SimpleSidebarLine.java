package eu.pb4.sidebars.api.lines;

import eu.pb4.sidebars.api.Sidebar;
import net.minecraft.class_2561;
import net.minecraft.class_3244;

/**
 * Simple implementation of SidebarLine
 */
public class SimpleSidebarLine extends AbstractSidebarLine {
    private class_2561 text;

    public SimpleSidebarLine(int value, class_2561 text) {
        this.text = text;
        this.value = value;
    }

    public SimpleSidebarLine(int value, class_2561 text, Sidebar sidebar) {
        this(value, text);
        this.sidebar = sidebar;
    }

    public class_2561 getText() {
        return this.text;
    }

    public class_2561 getText(class_3244 handler) {
        return this.getText();
    }

    public void setText(class_2561 text) {
        this.text = text;
    }
}
