package eu.pb4.sidebars.api.lines;

import eu.pb4.sidebars.api.Sidebar;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

/**
 * Minimalistic interface for creating own SidebarLines
 *
 */
public interface SidebarLine {
    /**
     * Returns score of this line (used for ordering)
     * Highest number is always on top
     */
    int getValue();

    /**
     * Changes value of sidebar line. Used by {@link LineBuilder}
     */
    boolean setValue(int value);

    /**
     * Gets text for selected player. Uses
     *
     * @param handler Player's ServerPlayNetworkHandler
     * @return Text displayed for player
     */
    class_2561 getText(class_3244 handler);

    /**
     * Creates a static, immutable copy of this SidebarLine, that's used for comparing
     */
    default ImmutableSidebarLine immutableCopy(class_3244 handler) {
        return new ImmutableSidebarLine(this.getValue(), this.getText(handler).method_27661());
    }

    /**
     * Sets active sidebar. Every SidebarLine should only have one sidebar!
     */
    void setSidebar(@Nullable Sidebar sidebar);

    /**
     * Quick way to create SidebarLine instance with more advanced text building
     *
     * @param value Scoreboard value
     * @param textBuilder Function creating text
     * @return SidebarLine 
     */
    static SidebarLine create(int value, Function<@Nullable class_3222, class_2561> textBuilder) {
        return new SuppliedSidebarLine(value, textBuilder);
    }

    /**
     * Quick way to create SidebarLine instance with more advanced text building
     *
     * @param value Scoreboard value
     * @param text Text
     * @return SidebarLine
     */
    static SidebarLine create(int value, class_2561 text) {
        return new SimpleSidebarLine(value, text);
    }

    /**
     * Quick way to create SidebarLine instance with more advanced text building
     *
     * @param value Scoreboard value
     * @return SidebarLine
     */
    static SidebarLine createEmpty(int value) {
        return new AbstractSidebarLine() {
            @Override
            public class_2561 getText() {
                return class_2585.field_24366;
            }
        };
    }
}
