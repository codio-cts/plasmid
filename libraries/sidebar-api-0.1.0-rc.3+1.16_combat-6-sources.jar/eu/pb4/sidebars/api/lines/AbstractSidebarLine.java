package eu.pb4.sidebars.api.lines;

import eu.pb4.sidebars.api.Sidebar;
import net.minecraft.class_2561;
import net.minecraft.class_3244;

public abstract class AbstractSidebarLine implements SidebarLine {
    protected int value;
    protected Sidebar sidebar;

    public int getValue() {
        return this.value;
    }

    public boolean setValue(int value) {
        this.value = value;
        if (this.sidebar != null) {
            this.sidebar.markDirty();
        }
        return true;
    }

    public abstract class_2561 getText();

    public class_2561 getText(class_3244 handler) {
        return this.getText();
    }

    public void setSidebar(Sidebar sidebar) {
        this.sidebar = sidebar;
    }
}
