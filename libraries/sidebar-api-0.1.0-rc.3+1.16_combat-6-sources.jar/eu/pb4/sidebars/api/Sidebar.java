package eu.pb4.sidebars.api;

import eu.pb4.sidebars.api.lines.LineBuilder;
import eu.pb4.sidebars.api.lines.SidebarLine;
import eu.pb4.sidebars.api.lines.SimpleSidebarLine;
import eu.pb4.sidebars.interfaces.SidebarHolder;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

/**
 * Basic sidebar with all basic functionality
 */
@SuppressWarnings({ "unused" })
public class Sidebar {
    protected List<SidebarLine> elements = new ArrayList<>();
    protected Set<class_3244> players = new HashSet<>();
    protected Priority priority;
    protected class_2561 title;
    protected boolean isDirty = false;
    protected int updateRate = 1;

    protected boolean isActive = false;

    public Sidebar(Priority priority) {
        this.priority = priority;
        this.title = new class_2585("");
    }

    public Sidebar(class_2561 title, Priority priority) {
        this.priority = priority;
        this.title = title;
    }

    public Priority getPriority() {
        return this.priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
        if (this.isActive) {
            for (class_3244 player : this.players) {
                ((SidebarHolder) player).updateCurrentSidebar(this);
            }
        }
    }

    public int getUpdateRate() {
        return this.updateRate;
    }

    public void setUpdateRate(int updateRate) {
        this.updateRate = Math.max(updateRate, 1);
    }

    public class_2561 getTitle() {
        return this.title;
    }

    public void setTitle(class_2561 title) {
        this.title = title;
    }

    public void setLine(int value, class_2561 text) {
        for (SidebarLine line : this.elements) {
            if (line.getValue() == value) {
                this.elements.set(this.elements.indexOf(line), new SimpleSidebarLine(value, text, this));
                return;
            }
        }

        this.elements.add(new SimpleSidebarLine(value, text, this));
        this.isDirty = true;
    }

    public void setLine(SidebarLine line) {
        for (SidebarLine cLine : this.elements) {
            if (line.getValue() == cLine.getValue()) {
                line.setSidebar(this);
                this.elements.set(this.elements.indexOf(cLine), line);
                return;
            }
        }

        this.elements.add(line);
        this.isDirty = true;
    }

    public void addLines(SidebarLine... lines) {
        for (SidebarLine line : lines) {
            line.setSidebar(this);
            this.elements.add(line);
        }

        this.isDirty = true;
    }


    public void addLines(class_2561... texts) {
        if (this.elements.isEmpty()) {
            int lastLine = texts.length;
            for (class_2561 t : texts) {
                this.elements.add(new SimpleSidebarLine(--lastLine, t, this));
            }
        } else {
            this.sortIfDirty();
            int lastLine = this.elements.get(this.elements.size() - 1).getValue();
            for (class_2561 t : texts) {
                this.elements.add(new SimpleSidebarLine(--lastLine, t, this));
            }
        }
    }

    public void removeLine(SidebarLine line) {
        this.elements.remove(line);
        line.setSidebar(null);
    }

    public void removeLine(int value) {
        for (SidebarLine line : new ArrayList<>(this.elements)) {
            if (line.getValue() == value) {
                this.elements.remove(line);
                line.setSidebar(null);
            }
        }
    }

    public SidebarLine getLine(int value) {
        for (SidebarLine line : this.elements) {
            if (line.getValue() == value) {
                return line;
            }
        }

        return null;
    }

    public void replaceLines(class_2561... texts) {
        this.clearLines();
        this.addLines(texts);
    }

    public void replaceLines(SidebarLine... lines) {
        this.clearLines();
        this.addLines(lines);
    }

    public void replaceLines(LineBuilder builder) {
        this.replaceLines(builder.getLines().toArray(new SidebarLine[0]));
    }

    public void clearLines() {
        for (SidebarLine line : this.elements) {
            line.setSidebar(null);
        }

        this.elements.clear();
    }

    public void set(Consumer<LineBuilder> consumer) {
        LineBuilder builder = new LineBuilder();
        consumer.accept(builder);
        this.replaceLines(builder);
    }

    public boolean isDirty() {
        return this.isDirty;
    }

    public void markDirty() {
        this.isDirty = true;
    }

    public List<SidebarLine> getLinesFor(class_3244 handler) {
        this.sortIfDirty();

        return this.elements.subList(0, Math.min(14, this.elements.size()));
    }

    protected void sortIfDirty() {
        if (this.isDirty) {
            this.isDirty = false;
            this.elements.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        }
    }

    public void show() {
        if (!isActive) {
            this.isActive = true;
            for (class_3244 player : this.players) {
                ((SidebarHolder) player).addSidebar(this);
            }
        }
    }

    public void hide() {
        if (this.isActive) {
            this.isActive = false;
            for (class_3244 player : this.players) {
                ((SidebarHolder) player).removeSidebar(this);
            }
        }
    }

    public boolean isActive() {
        return this.isActive;
    }

    public void addPlayer(class_3244 handler) {
        if (this.players.add(handler)) {
            if (isActive) {
                ((SidebarHolder) handler).addSidebar(this);
            }
        }
    }

    public void removePlayer(class_3244 handler) {
        if (this.players.remove(handler)) {
            if (isActive) {
                if (!handler.field_14140.method_14239()) {
                    ((SidebarHolder) handler).removeSidebar(this);
                }
            }
        }
    }

    public void addPlayer(class_3222 player) {
        this.addPlayer(player.field_13987);
    }

    public void removePlayer(class_3222 player) {
        this.removePlayer(player.field_13987);
    }

    public Set<class_3244> getPlayerHandlerSet() {
        return Collections.unmodifiableSet(this.players);
    }


    public enum Priority {
        LOWEST(0),
        LOW(1),
        MEDIUM(2),
        HIGH(3),
        OVERRIDE(4);

        private final int value;

        Priority(int value) {
            this.value = value;
        }

        public boolean isLowerThan(Priority priority) {
            return this.value <= priority.value;
        }
    }
}
