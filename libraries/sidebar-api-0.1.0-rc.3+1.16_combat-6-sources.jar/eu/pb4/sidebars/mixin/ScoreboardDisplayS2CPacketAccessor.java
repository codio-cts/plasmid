package eu.pb4.sidebars.mixin;

import net.minecraft.class_2736;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2736.class)
public interface ScoreboardDisplayS2CPacketAccessor {
    @Mutable
    @Accessor("name")
    void setName(String name);
}
