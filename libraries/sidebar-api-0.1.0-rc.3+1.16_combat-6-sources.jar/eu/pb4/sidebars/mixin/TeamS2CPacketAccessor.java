package eu.pb4.sidebars.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_2755;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2755.class)
public interface TeamS2CPacketAccessor {
    @Mutable
    @Accessor("prefix")
    void setPrefix(class_2561 text);
}
