package eu.pb4.sidebars.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_2751;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2751.class)
public interface SOUS2CPacketAccessor {
    @Mutable
    @Accessor("displayName")
    void setTitle(class_2561 name);
}
